package weatherapp

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
